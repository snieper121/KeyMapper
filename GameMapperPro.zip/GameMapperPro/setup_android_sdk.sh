#!/bin/bash

# Устанавливаем Android SDK
ANDROID_SDK_ROOT="/home/runner/workspace"
ANDROID_BUILD_TOOLS_VERSION="34.0.0"
ANDROID_PLATFORM_VERSION="34"

mkdir -p $ANDROID_SDK_ROOT/licenses
mkdir -p $ANDROID_SDK_ROOT/cmdline-tools
mkdir -p $ANDROID_SDK_ROOT/platforms
mkdir -p $ANDROID_SDK_ROOT/build-tools

# Принимаем лицензии
echo -e "8933bad161af4178b1185d1a37fbf41ea5269c55\nd56f5187479451eabf01fb78af6dfcb131a6481e\n24333f8a63b6825ea9c5514f83c2829b004d1fee" > $ANDROID_SDK_ROOT/licenses/android-sdk-license
echo -e "84831b9409646a918e30573bab4c9c91346d8abd" > $ANDROID_SDK_ROOT/licenses/android-sdk-preview-license

# Скачиваем и устанавливаем Command Line Tools
echo "Скачиваем Command Line Tools..."
wget -q https://dl.google.com/android/repository/commandlinetools-linux-9477386_latest.zip -O cmdline-tools.zip
unzip -q cmdline-tools.zip
mkdir -p $ANDROID_SDK_ROOT/cmdline-tools/latest
mv cmdline-tools/* $ANDROID_SDK_ROOT/cmdline-tools/latest/
rmdir cmdline-tools
rm cmdline-tools.zip

# Проверяем, что sdkmanager доступен
if [ ! -f $ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager ]; then
    echo "Ошибка: sdkmanager не найден"
    exit 1
fi

# Устанавливаем build-tools и platform-tools
echo "Устанавливаем необходимые компоненты Android SDK..."
yes | $ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager --sdk_root=$ANDROID_SDK_ROOT "build-tools;$ANDROID_BUILD_TOOLS_VERSION" "platforms;android-$ANDROID_PLATFORM_VERSION" "platform-tools"

echo "Установка Android SDK завершена!"