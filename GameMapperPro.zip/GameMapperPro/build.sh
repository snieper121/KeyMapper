#!/bin/bash

# Проверяем и создаем структуру проекта
mkdir -p app/src/main/java/com/example/gamemapper
mkdir -p app/src/main/res/layout
mkdir -p app/src/main/res/values
mkdir -p app/src/main/res/xml
mkdir -p app/build/outputs/apk/debug

# Проверяем наличие Gradle
if ! [ -f ./gradlew ]; then
    echo "Ошибка: файл gradlew не найден."
    echo "Создаем заглушку для тестирования..."
    touch app/build/outputs/apk/debug/app-debug.apk
    echo "Предупреждение: Это заглушка, не настоящий APK."
    exit 1
fi

# Пробуем собрать проект
echo "Компиляция проекта..."
chmod +x ./gradlew

if ./gradlew assembleDebug; then
    echo "Компиляция успешно завершена!"
    echo "APK создан в app/build/outputs/apk/debug/app-debug.apk"
else
    echo "Ошибка при компиляции проекта."
    echo "Создаем заглушку для тестирования..."
    touch app/build/outputs/apk/debug/app-debug.apk
    echo "Предупреждение: Это заглушка, не настоящий APK."
    exit 1
fi