package com.example.gamemapper

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Менеджер для записи и воспроизведения макросов пользовательских действий
 */
object RecorderManager {
    
    private const val TAG = "RecorderManager"
    
    // Структура для хранения записанных действий
    data class Action(
        val timestamp: Long,
        val keyCode: Int,
        val x: Float,
        val y: Float
    )
    
    private val recordedActions = mutableListOf<Action>()
    private var isRecording = false
    private var recordingStartTime: Long = 0
    
    /**
     * Начать запись последовательности действий
     */
    fun startRecording() {
        recordedActions.clear()
        isRecording = true
        recordingStartTime = SystemClock.elapsedRealtime()
        Log.d(TAG, "Recording started")
    }
    
    /**
     * Остановить запись
     */
    fun stopRecording() {
        isRecording = false
        Log.d(TAG, "Recording stopped, recorded ${recordedActions.size} actions")
    }
    
    /**
     * Записать действие пользователя
     */
    fun recordAction(keyCode: Int, x: Float, y: Float) {
        if (!isRecording) return
        
        val timestamp = SystemClock.elapsedRealtime() - recordingStartTime
        val action = Action(timestamp, keyCode, x, y)
        recordedActions.add(action)
        
        Log.d(TAG, "Recorded action: key=$keyCode, x=$x, y=$y, time=$timestamp")
    }
    
    /**
     * Воспроизвести записанную последовательность действий
     */
    fun playRecording(mappingService: MappingService) {
        if (recordedActions.isEmpty()) {
            Log.w(TAG, "No actions to play")
            return
        }
        
        val handler = Handler(Looper.getMainLooper())
        
        Log.d(TAG, "Playing ${recordedActions.size} recorded actions")
        
        // Проигрываем каждое действие с задержкой согласно временным меткам
        recordedActions.forEachIndexed { index, action ->
            val delay = if (index == 0) 0 else action.timestamp - recordedActions[index - 1].timestamp
            
            handler.postDelayed({
                // Запрашиваем у сервиса выполнение виртуального касания
                mappingService.performVirtualTouch(action.x, action.y)
                Log.d(TAG, "Played action: key=${action.keyCode}, x=${action.x}, y=${action.y}")
            }, delay)
        }
    }
    
    /**
     * Сохранить записанную последовательность в файл
     */
    fun saveRecording(file: File): Boolean {
        if (recordedActions.isEmpty()) {
            Log.w(TAG, "No actions to save")
            return false
        }
        
        try {
            val output = FileOutputStream(file)
            output.use { stream ->
                for (action in recordedActions) {
                    val line = "${action.timestamp},${action.keyCode},${action.x},${action.y}\n"
                    stream.write(line.toByteArray())
                }
            }
            Log.d(TAG, "Saved ${recordedActions.size} actions to ${file.absolutePath}")
            return true
        } catch (e: IOException) {
            Log.e(TAG, "Failed to save recording", e)
            return false
        }
    }
    
    /**
     * Загрузить записанную последовательность из файла
     */
    fun loadRecording(file: File): Boolean {
        recordedActions.clear()
        
        try {
            file.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val parts = line.split(",")
                    if (parts.size == 4) {
                        try {
                            val timestamp = parts[0].toLong()
                            val keyCode = parts[1].toInt()
                            val x = parts[2].toFloat()
                            val y = parts[3].toFloat()
                            
                            recordedActions.add(Action(timestamp, keyCode, x, y))
                        } catch (e: NumberFormatException) {
                            Log.w(TAG, "Ignoring invalid line in recording file: $line")
                        }
                    }
                }
            }
            
            Log.d(TAG, "Loaded ${recordedActions.size} actions from ${file.absolutePath}")
            return recordedActions.isNotEmpty()
        } catch (e: IOException) {
            Log.e(TAG, "Failed to load recording", e)
            return false
        }
    }
    
    /**
     * Получить список всех записанных действий
     */
    fun getRecordedActions(): List<Action> {
        return recordedActions.toList()
    }
    
    /**
     * Проверить, идет ли запись в данный момент
     */
    fun isRecording(): Boolean {
        return isRecording
    }
}

// Примечание: Теперь performVirtualTouch в MappingService объявлен как public,
// поэтому нам не нужно использовать рефлексию для доступа к нему.
// Это расширение было удалено, теперь мы используем метод напрямую в playRecording.