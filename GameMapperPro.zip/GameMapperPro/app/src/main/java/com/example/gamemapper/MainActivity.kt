package com.example.gamemapper

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    
    private lateinit var startServiceButton: Button
    private lateinit var stopServiceButton: Button
    private lateinit var createMappingButton: Button
    private lateinit var editMappingButton: Button
    private lateinit var loadMappingButton: Button
    private lateinit var saveMappingButton: Button
    private lateinit var statusTextView: TextView
    
    private var isRecording = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Находим все элементы UI
        startServiceButton = findViewById(R.id.startServiceButton)
        stopServiceButton = findViewById(R.id.stopServiceButton)
        createMappingButton = findViewById(R.id.createMappingButton)
        editMappingButton = findViewById(R.id.editMappingButton)
        loadMappingButton = findViewById(R.id.loadMappingButton)
        saveMappingButton = findViewById(R.id.saveMappingButton)
        statusTextView = findViewById(R.id.statusTextView)
        
        // Настраиваем обработчики кликов
        startServiceButton.setOnClickListener {
            if (!isAccessibilityServiceEnabled()) {
                // Если сервис не включен, перенаправляем в настройки специальных возможностей
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this, "Пожалуйста, включите сервис GameMapper в настройках специальных возможностей", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Сервис GameMapper уже запущен", Toast.LENGTH_SHORT).show()
            }
        }
        
        stopServiceButton.setOnClickListener {
            // Перенаправляем в настройки для выключения сервиса
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Пожалуйста, отключите сервис GameMapper в настройках", Toast.LENGTH_LONG).show()
        }
        
        createMappingButton.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Создание новой карты кнопок...", Toast.LENGTH_SHORT).show()
                // Здесь будет реализация создания новой карты
            } else {
                promptEnableService()
            }
        }
        
        editMappingButton.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Редактирование карты кнопок...", Toast.LENGTH_SHORT).show()
                // Здесь будет реализация редактирования карты
            } else {
                promptEnableService()
            }
        }
        
        loadMappingButton.setOnClickListener {
            Toast.makeText(this, "Загрузка карты кнопок...", Toast.LENGTH_SHORT).show()
            // Здесь будет реализация загрузки карты
        }
        
        saveMappingButton.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                Toast.makeText(this, "Сохранение карты кнопок...", Toast.LENGTH_SHORT).show()
                // Здесь будет реализация сохранения карты
            } else {
                promptEnableService()
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        updateUI()
    }
    
    private fun updateUI() {
        val serviceEnabled = isAccessibilityServiceEnabled()
        
        // Обновляем состояние кнопок в зависимости от статуса сервиса
        stopServiceButton.isEnabled = serviceEnabled
        createMappingButton.isEnabled = true // Всегда доступна
        editMappingButton.isEnabled = serviceEnabled
        loadMappingButton.isEnabled = true // Всегда доступна
        saveMappingButton.isEnabled = serviceEnabled
        
        // Обновляем текст статуса
        if (serviceEnabled) {
            statusTextView.text = "Статус: Сервис запущен"
        } else {
            statusTextView.text = "Статус: Сервис не запущен"
        }
    }
    
    private fun promptEnableService() {
        Toast.makeText(this, "Сначала необходимо включить сервис GameMapper", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
    
    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceName = packageName + "/" + MappingService::class.java.canonicalName
        val accessibilityEnabled = Settings.Secure.getInt(
            contentResolver,
            Settings.Secure.ACCESSIBILITY_ENABLED, 0
        )
        
        if (accessibilityEnabled == 1) {
            val settingValue = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            if (settingValue != null) {
                return settingValue.split(':').contains(serviceName)
            }
        }
        return false
    }
}