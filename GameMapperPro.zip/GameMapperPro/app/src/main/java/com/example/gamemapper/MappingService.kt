package com.example.gamemapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.input.InputManager
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import java.lang.reflect.Method

/**
 * Сервис доступности для перехвата ввода клавиатуры и мыши и эмуляции сенсорных нажатий
 */
class MappingService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlayButtons = mutableListOf<View>()
    private var mouseLookAreas = mutableListOf<View>()
    
    // Карта привязки клавиш к координатам нажатий
    private val keyMappings = mutableMapOf<Int, Pair<Float, Float>>()
    
    override fun onServiceConnected() {
        val info = AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        
        serviceInfo = info
        
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        
        // Создаем начальные привязки клавиш
        setupDefaultKeyMappings()
        
        // Создаем наложение кнопок
        createOverlayButtons()
        
        Toast.makeText(this, "GameMapper service started", Toast.LENGTH_SHORT).show()
    }
    
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        // Обработка событий доступности по необходимости
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && event.eventType == AccessibilityEvent.TYPE_VIEW_HOVER_ENTER) {
            // Обрабатываем событие наведения мыши, если возможно
            try {
                // Получаем событие движения мыши из AccessibilityEvent, если оно есть
                val source = event.source
                if (source != null) {
                    // Получаем координаты из источника события, если возможно
                    val rect = Rect()
                    source.getBoundsInScreen(rect)
                    
                    val motionEvent = MotionEvent.obtain(
                        System.currentTimeMillis(),
                        System.currentTimeMillis(),
                        MotionEvent.ACTION_HOVER_MOVE,
                        rect.centerX().toFloat(),
                        rect.centerY().toFloat(),
                        0
                    )
                    motionEvent.source = InputDevice.SOURCE_MOUSE
                    processMotionEvent(motionEvent)
                    motionEvent.recycle()
                }
            } catch (e: Exception) {
                Log.e("MappingService", "Error processing hover event: ${e.message}")
            }
        }
    }
    
    override fun onInterrupt() {
        // Обработка прерывания сервиса
    }
    
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Проверяем, есть ли привязка для этой клавиши
        val keyCode = event.keyCode
        val mapping = keyMappings[keyCode] ?: return false
        
        // Если клавиша нажата, выполняем виртуальное касание
        if (event.action == KeyEvent.ACTION_DOWN) {
            performVirtualTouch(mapping.first, mapping.second)
            return true // Перехватываем событие
        }
        
        return false
    }
    
    @RequiresApi(Build.VERSION_CODES.O)
    fun processMotionEvent(event: MotionEvent): Boolean {
        // Обрабатываем только события мыши
        if (event.source and InputDevice.SOURCE_MOUSE != InputDevice.SOURCE_MOUSE) {
            return false
        }
        
        // Проверка на событие движения мыши
        if (event.action == MotionEvent.ACTION_HOVER_MOVE) {
            // Получаем текущие координаты мыши
            val x = event.rawX
            val y = event.rawY
            
            // Проверяем, находится ли мышь внутри области управления камерой
            for (area in mouseLookAreas) {
                val location = IntArray(2)
                area.getLocationOnScreen(location)
                
                val areaX = location[0]
                val areaY = location[1]
                val areaWidth = area.width
                val areaHeight = area.height
                
                if (x >= areaX && x <= areaX + areaWidth &&
                    y >= areaY && y <= areaY + areaHeight) {
                    
                    // Вычисляем относительные координаты внутри области
                    val relativeX = x - areaX
                    val relativeY = y - areaY
                    
                    // Центр области
                    val centerX = areaWidth / 2f
                    val centerY = areaHeight / 2f
                    
                    // Расстояние от центра
                    val deltaX = relativeX - centerX
                    val deltaY = relativeY - centerY
                    
                    // Вычисляем виртуальное движение пальца для эмуляции движения камеры
                    // Масштабируем движение для более плавного управления
                    val scaleFactor = 0.5f
                    
                    if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
                        // Создаем виртуальное движение пальца в центре области управления камерой
                        simulateDrag(
                            areaX + centerX, 
                            areaY + centerY,
                            areaX + centerX + deltaX * scaleFactor,
                            areaY + centerY + deltaY * scaleFactor
                        )
                        
                        Log.d("MappingService", "Mouse look: deltaX=$deltaX, deltaY=$deltaY")
                    }
                    
                    return true
                }
            }
        }
        
        // Обработка кликов мышью
        if (event.buttonState and MotionEvent.BUTTON_PRIMARY != 0) {
            // Обработка левого клика мыши
            val x = event.rawX
            val y = event.rawY
            
            performVirtualTouch(x, y)
            Log.d("MappingService", "Mouse click at: x=$x, y=$y")
            return true
        }
        
        return false
    }
    
    private fun setupDefaultKeyMappings() {
        // Стандартные привязки клавиш для WASD и кнопок управления
        keyMappings[KeyEvent.KEYCODE_W] = Pair(500f, 300f) // Вперед
        keyMappings[KeyEvent.KEYCODE_A] = Pair(200f, 500f) // Влево
        keyMappings[KeyEvent.KEYCODE_S] = Pair(500f, 700f) // Назад
        keyMappings[KeyEvent.KEYCODE_D] = Pair(800f, 500f) // Вправо
        keyMappings[KeyEvent.KEYCODE_SPACE] = Pair(900f, 800f) // Прыжок
        keyMappings[KeyEvent.KEYCODE_E] = Pair(1000f, 300f) // Действие
        keyMappings[KeyEvent.KEYCODE_R] = Pair(1100f, 400f) // Перезарядка
    }
    
    private fun createOverlayButtons() {
        // Создаем кнопки-наложения для отображения привязок
        for ((keyCode, position) in keyMappings) {
            createOverlayButton(keyCode, position.first, position.second)
        }
        
        // Создаем область для управления камерой мышью
        createMouseLookArea(600f, 400f, 400f, 300f)
    }
    
    private fun createOverlayButton(keyCode: Int, x: Float, y: Float) {
        val button = Button(this)
        button.text = KeyEvent.keyCodeToString(keyCode).replace("KEYCODE_", "")
        button.setBackgroundColor(Color.parseColor("#80FFFFFF")) // Полупрозрачный белый
        
        val params = WindowManager.LayoutParams(
            120, // Ширина
            120, // Высота
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        
        params.gravity = Gravity.TOP or Gravity.START
        params.x = x.toInt()
        params.y = y.toInt()
        
        // Разрешаем перетаскивание кнопки для изменения позиции
        button.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(v, params)
                        
                        // Обновляем карту привязки
                        keyMappings[keyCode] = Pair(params.x.toFloat(), params.y.toFloat())
                        return true
                    }
                }
                return false
            }
        })
        
        windowManager.addView(button, params)
        overlayButtons.add(button)
    }
    
    private fun createMouseLookArea(x: Float, y: Float, width: Float, height: Float) {
        val view = View(this)
        view.setBackgroundColor(Color.parseColor("#40FF0000")) // Полупрозрачный красный
        
        val params = WindowManager.LayoutParams(
            width.toInt(),
            height.toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        
        params.gravity = Gravity.TOP or Gravity.START
        params.x = x.toInt()
        params.y = y.toInt()
        
        // Разрешаем перетаскивание области
        view.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(v, params)
                        return true
                    }
                }
                return false
            }
        })
        
        windowManager.addView(view, params)
        mouseLookAreas.add(view)
    }
    
    fun performVirtualTouch(x: Float, y: Float) {
        // Используем private API для симуляции касаний
        try {
            val inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
            val injectInputEventMethod = InputManager::class.java.getDeclaredMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.java
            )
            injectInputEventMethod.isAccessible = true
            
            // Создаем события для DOWN, UP
            val downTime = System.currentTimeMillis()
            
            val down = MotionEvent.obtain(
                downTime, downTime, MotionEvent.ACTION_DOWN,
                x, y, 0
            )
            
            val up = MotionEvent.obtain(
                downTime, downTime + 50, MotionEvent.ACTION_UP,
                x, y, 0
            )
            
            // Инжектируем события
            injectInputEventMethod.invoke(inputManager, down, 0)
            injectInputEventMethod.invoke(inputManager, up, 0)
            
            down.recycle()
            up.recycle()
            
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to simulate touch: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * Симуляция перетаскивания пальца по экрану (свайп)
     */
    private fun simulateDrag(startX: Float, startY: Float, endX: Float, endY: Float) {
        try {
            val inputManager = getSystemService(Context.INPUT_SERVICE) as InputManager
            val injectInputEventMethod = InputManager::class.java.getDeclaredMethod(
                "injectInputEvent", InputEvent::class.java, Int::class.java
            )
            injectInputEventMethod.isAccessible = true
            
            val downTime = System.currentTimeMillis()
            
            // Создаем событие начала касания (ACTION_DOWN)
            val down = MotionEvent.obtain(
                downTime, downTime, MotionEvent.ACTION_DOWN,
                startX, startY, 0
            )
            
            // Создаем событие движения (ACTION_MOVE)
            val move = MotionEvent.obtain(
                downTime, downTime + 50, MotionEvent.ACTION_MOVE,
                endX, endY, 0
            )
            
            // Создаем событие окончания касания (ACTION_UP)
            val up = MotionEvent.obtain(
                downTime, downTime + 100, MotionEvent.ACTION_UP,
                endX, endY, 0
            )
            
            // Инжектируем события
            injectInputEventMethod.invoke(inputManager, down, 0)
            injectInputEventMethod.invoke(inputManager, move, 0)
            injectInputEventMethod.invoke(inputManager, up, 0)
            
            // Очищаем объекты событий
            down.recycle()
            move.recycle()
            up.recycle()
            
            Log.d("MappingService", "Simulated drag from ($startX, $startY) to ($endX, $endY)")
            
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("MappingService", "Failed to simulate drag: ${e.message}")
        }
    }
    
    override fun onDestroy() {
        super.onDestroy()
        
        // Очищаем все наложения
        for (button in overlayButtons) {
            windowManager.removeView(button)
        }
        overlayButtons.clear()
        
        for (area in mouseLookAreas) {
            windowManager.removeView(area)
        }
        mouseLookAreas.clear()
    }
}